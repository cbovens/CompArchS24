Both the lab report and test vector extra credits were completed.
To run the FSM:
vsim -do FSM.do
to run the register array:
vsim -do rf.do